package employee.version1;

import java.time.LocalDate;

public class CommissionEmployee {
	private int empID;
    private String empName;
    private LocalDate empDateHired;
    private LocalDate empBirthDate;
    private double totalSales;
    private double salary;
	double commission = 0;

    
    CommissionEmployee(int empID, String empName, LocalDate empDateHired, LocalDate empBirthDate, double totalSales){
    	this.empID = empID;
        this.empName = empName;
        this.empDateHired = empDateHired;
        this.empBirthDate = empBirthDate;
        this.totalSales = totalSales;

    }
    public double getTotalSales() {
		return totalSales;
	}
    
    public void setTotalSales(double totalSales) {
		this.totalSales = totalSales;
	}
    public int getEmpID() {
        return empID;
    }

    public void setEmpID(int empID) {
        this.empID = empID;
    }

    public String getEmpName() {
        return empName;
    }

    public void setEmpName(String empName) {
        this.empName = empName;
    }
    public LocalDate getEmpDateHired() {
        return empDateHired;
    }

    public void setEmpDateHired(LocalDate empDateHired) {
        this.empDateHired = empDateHired;
    }

    public LocalDate getEmpBirthDate() {
        return empBirthDate;
    }

    public void setEmpBirthDate(LocalDate empBirthDate) {
        this.empBirthDate = empBirthDate;
    }
    public double computeSalary() {
    	if(totalSales >= 500000) {
    		commission = .5;
    	}
    	else if(totalSales>=100000 && totalSales<500000) {
    		commission = .3;
    	}
    	else if(totalSales>=50000 && totalSales < 100000) {
    		commission = .2;
    	}
    	else if(totalSales>50000) {
    		commission = .05;
    	}
    	
    	salary = totalSales * commission;
    	return salary;
    }
    public void displayInfo(){
        System.out.println("Employee ID: " + getEmpID() + "\nEmployee Name: " + getEmpName() + "\nTotalSales: " + getTotalSales()+ "\nSalary: " + computeSalary());
    }
    
    public String toString() {
    	return "Employee ID: " + getEmpID() + "\nEmployee Name: " + getEmpName() + "\nDate hired: "+ getEmpDateHired() + "\nDate of birth: " + getEmpBirthDate(); 
    }    

}
