package employee.version1;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Locale;
import java.util.Scanner;

public class TestMain {

    public static void main(String[] args) {    	
        Scanner scanner = new Scanner(System.in);   
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d/M/uuuu", Locale.US);  
      float ratePerHour;
      double totalSales;
      

        System.out.println("Enter option: \n1. Hourly Employee\n2. Piece Worker Employee\n3. Commission Employee\n4. Base Plus Commission Employee");
        int opt = scanner.nextInt();
        
        //ENTER EMPLOYEE DETAILS
        System.out.println("Enter employee ID: ");
        int empID = scanner.nextInt();
        scanner.nextLine();
        

        System.out.println("Enter employee name: ");
        String empName = scanner.nextLine();


        System.out.print("Enter date hired (dd/mm/yyyy): ");
        String dateHiredStr = scanner.next();
        LocalDate empDateHired = LocalDate.parse(dateHiredStr, formatter);  
        System.out.println("Date is: " + empDateHired);
        
        System.out.print("Enter date of birth (dd/mm/yyyy): ");
        String dateBirthStr = scanner.next();
        LocalDate empBirthDate= LocalDate.parse(dateBirthStr, formatter);  
        System.out.println("Date is: " + empBirthDate);
        
        switch(opt) {
        case 1:
          System.out.println("Enter total hours worked: ");
          float totalHoursWorked = scanner.nextFloat();
            
          System.out.println("Enter the rate per hour: ");
          ratePerHour = scanner.nextFloat();
          
          HourlyEmployee detailsHE = new HourlyEmployee(empID, empName, empDateHired, empBirthDate, totalHoursWorked, ratePerHour);
          detailsHE.displayInfo();
//          resToString = detailsHE.toString();
//          System.out.println(resToString);
          break;
          
        case 2:
          System.out.println("Enter number of pieces made: ");
          int totalPiecesFinished = scanner.nextInt();
          System.out.println("Enter the rate per hour: ");
          ratePerHour = scanner.nextFloat();
          
          PieceWorkerEmployee detailsPWE = new PieceWorkerEmployee(empID, empName, empDateHired, empBirthDate, totalPiecesFinished, ratePerHour);
          detailsPWE.displayInfo();
          break;
          
        case 3:
    	 System.out.println("Enter total sales: ");
         totalSales= scanner.nextDouble();
         
         CommissionEmployee detailsCE = new CommissionEmployee(empID, empName, empDateHired, empBirthDate, totalSales);
         detailsCE.displayInfo();
         break;
         
        case 4:
       	 System.out.println("Enter total sales: ");
         totalSales= scanner.nextDouble();
         
    	 System.out.println("Enter base salary: ");
         double baseSalary = scanner.nextDouble();
        	
         BasePlusCommissionEmployee detailsBPCE = new BasePlusCommissionEmployee(empID, empName, empDateHired, empBirthDate, totalSales, baseSalary);
         detailsBPCE.displayInfo();
        }

        	


        

        scanner.close();
    }
    
}
