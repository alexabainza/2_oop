package employee.version1;

import java.time.LocalDate;

public class PieceWorkerEmployee {
	private int empID;
    private String empName;
    private LocalDate empDateHired;
    private LocalDate empBirthDate;
    private int totalPiecesFinished;
    private float ratePerHour;
    private double salary;



    PieceWorkerEmployee(int empID, String empName, LocalDate empDateHired, LocalDate empBirthDate,  int totalPiecesFinished, float ratePerHour){
        this.empID = empID;
        this.empName = empName;
        this.empDateHired = empDateHired;
        this.empBirthDate = empBirthDate;
        this.ratePerHour = ratePerHour;
        this.totalPiecesFinished = totalPiecesFinished;
    }
    
    public int getEmpID() {
        return empID;
    }

    public void setEmpID(int empID) {
        this.empID = empID;
    }

    public String getEmpName() {
        return empName;
    }

    public void setEmpName(String empName) {
        this.empName = empName;
    }

    public LocalDate getEmpDateHired() {
        return empDateHired;
    }

    public void setEmpDateHired(LocalDate empDateHired) {
        this.empDateHired = empDateHired;
    }

    public LocalDate getEmpBirthDate() {
        return empBirthDate;
    }

    public void setEmpBirthDate(LocalDate empBirthDate) {
        this.empBirthDate = empBirthDate;
    }

    public int gettotalPiecesFinished() {
        return totalPiecesFinished;
    }

    public void settotalPiecesFinished(int totalPiecesFinished) {
        this.totalPiecesFinished = totalPiecesFinished;
    }

    public float getRatePerHour() {
        return ratePerHour;
    }

    public void setRatePerHour(float ratePerHour) {
        this.ratePerHour = ratePerHour;
    }
    
    public double computeSalary(int totalPiecesFinished, float ratePerHour){
    	int numHundred;
    	if(totalPiecesFinished>100) {
    		numHundred = (int)totalPiecesFinished/100;
    		salary = (totalPiecesFinished * ratePerHour) + (numHundred*10*ratePerHour);
    	}
    	else {
    		salary = totalPiecesFinished * ratePerHour;
    	}
    	return salary;
    }
         
    
    public void displayInfo(){
        System.out.println("Employee ID: " + getEmpID() + "\nEmployee Name: " + getEmpName() + "\nRate per hour: " + getRatePerHour() + "\nPieces finished: " + gettotalPiecesFinished() + "\nSalary: " + computeSalary(totalPiecesFinished,ratePerHour));
    }
    
    public String toString() {
    	return "Employee ID: " + getEmpID() + "\nEmployee Name: " + getEmpName() + "\nDate hired: "+ getEmpDateHired() + "\nDate of birth: " + getEmpBirthDate(); 
    }    
}
