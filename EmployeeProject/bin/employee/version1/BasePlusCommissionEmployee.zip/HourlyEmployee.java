/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package employee.version1;

import java.time.LocalDate;

/**
 *
 * @author User
 */
public class HourlyEmployee {
    private int empID;
    private String empName;
    private LocalDate empDateHired;
    private LocalDate empBirthDate;
    private float totalHoursWorked;
    private float ratePerHour;
    private double salary;

    HourlyEmployee(int empID, String empName, LocalDate empDateHired, LocalDate empBirthDate, float totalHoursWorked, float ratePerHour){
        this.empID = empID;
        this.empName = empName;
        this.empDateHired = empDateHired;
        this.empBirthDate = empBirthDate;
        this.totalHoursWorked = totalHoursWorked;
        this.ratePerHour = ratePerHour;
    }
    
    public int getEmpID() {
        return empID;
    }

    public void setEmpID(int empID) {
        this.empID = empID;
    }

    public String getEmpName() {
        return empName;
    }

    public void setEmpName(String empName) {
        this.empName = empName;
    }

    public LocalDate getEmpDateHired() {
        return empDateHired;
    }

    public void setEmpDateHired(LocalDate empDateHired) {
        this.empDateHired = empDateHired;
    }

    public LocalDate getEmpBirthDate() {
        return empBirthDate;
    }

    public void setEmpBirthDate(LocalDate empBirthDate) {
        this.empBirthDate = empBirthDate;
    }

    public float getTotalHoursWorked() {
        return totalHoursWorked;
    }

    public void setTotalHoursWorked(float totalHoursWorked) {
        this.totalHoursWorked = totalHoursWorked;
    }

    public float getRatePerHour() {
        return ratePerHour;
    }

    public void setRatePerHour(float ratePerHour) {
        this.ratePerHour = ratePerHour;
    }
    
    public double computeSalary(){
        int extraHours;
        if(totalHoursWorked>40){
            extraHours = (int)(totalHoursWorked % 8.0);
            salary = (getRatePerHour()*(getTotalHoursWorked()-extraHours))+(extraHours*1.5*getRatePerHour());
        }
        else{
            salary = (getRatePerHour()*getTotalHoursWorked());

        }
        return salary;
    }
         
    public void displayInfo(){
        System.out.println("Employee ID: " + getEmpID() + "\nEmployee Name: " + getEmpName() + "\nRate per hour: " + getRatePerHour() + "\nHours worked: " + getTotalHoursWorked() + "\nSalary: " + computeSalary());
    }
    
//    @override
    public String toString() {
    	return "Employee ID: " + getEmpID() + "\nEmployee Name: " + getEmpName() + "\nDate hired: "+ getEmpDateHired() + "\nDate of birth: " + getEmpBirthDate(); 
    }
    
}
